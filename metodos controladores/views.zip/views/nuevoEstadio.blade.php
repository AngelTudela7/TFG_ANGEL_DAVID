<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alta Nuevo Estadio</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"></head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">MiAplicación</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarArbitros') }}">Arbitros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarJugadores') }}">Jugadores</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarCompeticiones') }}">Competiciones</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarEquipos') }}">Equipos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarJugadores') }}">Partidos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarEstadios') }}">Estadios</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Alta Nuevo Estadio</h2>
        <form action="{{ route('crearEstadio') }}" method="POST">
            @csrf
            <fieldset class="border p-4">
                <legend class="w-auto">Nuevo Estadio</legend>
                <div class="mb-3">
                    <label for="nombre_Estadio" class="form-label">Nombre</label>
                    <input type="text" name="nombre_Estadio" class="form-control">
                    @error('nombre_Estadio')
                        <div class="text-danger">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="pais" class="form-label">País</label>
                    <input type="text" name="pais" class="form-control">
                    @error('pais')
                        <div class="text-danger">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="ciudad" class="form-label">Ciudad</label>
                    <input type="text" name="ciudad" class="form-control">
                    @error('ciudad')
                        <div class="text-danger">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="aforo" class="form-label">Aforo</label>
                    <input type="number" name="aforo" class="form-control">
                    @error('aforo')
                        <div class="text-danger">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-success">Crear Estadio</button>
                    <a href="{{ route('principal') }}" class="btn btn-secondary">Volver</a>
                </div>
            </fieldset>
        </form>
        @if (session('mensaje'))
            <div class="alert alert-warning mt-3">
                {{ session('mensaje') }}
            </div>
        @endif
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script></body>
</html>
