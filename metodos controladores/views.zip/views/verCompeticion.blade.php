<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Información de Competiciones</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"></head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">MiAplicación</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarArbitros') }}">Arbitros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarJugadores') }}">Jugadores</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarCompeticiones') }}">Competiciones</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarEquipos') }}">Equipos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarJugadores') }}">Partidos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarEstadios') }}">Estadios</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <a href="{{ route('mostrarCompeticiones') }}" class="btn btn-primary mb-3">Volver</a>
        <h1 class="mb-4">Ver Información de Competiciones</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOMBRE</th>
                    <th>JORNADAS</th>
                    <th>EQUIPOS</th>
                    <th>PAIS</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ $compt->id}}</td>
                    <td>{{ $compt->nombre_Competicion }}</td>
                    <td>{{ $compt->numero_Jornadas }}</td>
                    <td>{{ $compt->numero_Equipos}}</td>
                    <td>{{ $compt->pais_Competicion}}</td>
                </tr>
            </tbody>
        </table>
        <hr>
        <h2 class="mt-4">Equipos de la Competición</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOMBRE</th>
                    <th>PAIS</th>
                    <th>CIUDAD</th>
                    <th>Nº PLANTILLA</th>
                    <th>ABREVIACION</th>
                </tr>
            </thead>
            <tbody>
                @if($equipo)
                @forelse($equipo as $equip)
                <tr>
                    <td>{{ $equip->id}}</td>
                    <td>{{ $equip->nombre_Equipo }}</td>
                    <td>{{ $equip->pais_Equipo}}</td>
                    <td>{{ $equip->ciudad_Equipo}}</td>
                    <td>{{ $equip->numero_plantilla}}</td>
                    <td>{{ $equip->abreviacion}}</td>
                </tr>
                @empty
                <tr>
                    <td colspan='6'>No se encontraron equipos para esta competición.</td>
                </tr>
                @endforelse
                @else
                <tr>
                    <td colspan="6"></td>
                </tr>
                @endif
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script></body>
</html>
