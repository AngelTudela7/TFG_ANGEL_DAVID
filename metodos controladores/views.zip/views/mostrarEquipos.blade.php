<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Equipos</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"></head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">MiAplicación</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarArbitros') }}">Arbitros</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarJugadores') }}">Jugadores</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarCompeticiones') }}">Competiciones</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarEquipos') }}">Equipos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarJugadores') }}">Partidos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarEstadios') }}">Estadios</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="#">Contacto</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container mt-5">
        <h1 class="mb-4">Listado de Equipos</h1>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>País</th>
                        <th>Ciudad</th>
                        <th>Número Plantilla</th>
                        <th>Abreviación</th>
                        <th>ID Competición</th>
                        <th>ID Estadio</th>
                        <th colspan="3" class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($equipos as $equipo)
                    <tr>
                        <td>{{ $equipo->id }}</td>
                        <td>{{ $equipo->nombre_Equipo }}</td>
                        <td>{{ $equipo->pais_Equipo }}</td>
                        <td>{{ $equipo->ciudad_Equipo }}</td>
                        <td>{{ $equipo->numero_plantilla }}</td>
                        <td>{{ $equipo->abreviacion }}</td>
                        <td>{{ $equipo->competicion_id }}</td>
                        <td>{{ $equipo->estadio_id }}</td>
                        <td class="text-center">
                            <a href="{{ route('verEquipo', $equipo->id) }}" class="btn btn-info btn-sm">Ver</a>
                        </td>
                        <td class="text-center">
                            <a href="{{ route('editarEquipo', $equipo->id) }}" class="btn btn-warning btn-sm">Editar</a>
                        </td>
                        <td class="text-center">
                            <form action="{{ route('eliminarEquipo', $equipo->id) }}" method="POST">
                                @method('DELETE')
                                @csrf
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="11" class="text-center">No hay equipos</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-center">
            {{ $equipos->links() }}
        </div>
        <a href="{{ route('mostrarEquipos') }}" class="btn btn-secondary mt-3">Volver</a>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script></body>
</html>
