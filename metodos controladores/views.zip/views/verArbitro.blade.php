<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Información de Árbitro</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"></head>
<body>
   <!-- Navbar -->
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">MiAplicación</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarArbitros') }}">Arbitros</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarJugadores') }}">Jugadores</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarCompeticiones') }}">Competiciones</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarEquipos') }}">Equipos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarJugadores') }}">Partidos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarEstadios') }}">Estadios</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="#">Contacto</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <a href="{{ route('mostrarArbitros') }}" class="btn btn-primary mb-3">Volver</a>
        <h1 class="mb-4">Ver Información de Árbitro</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOMBRE</th>
                    <th>APELLIDOS</th>
                    <th>NACIONALIDAD</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ $arbitro->id }}</td>
                    <td>{{ $arbitro->nombre_Arbitro }}</td>
                    <td>{{ $arbitro->apellidos_Arbitro }}</td>
                    <td>{{ $arbitro->nacionalidad }}</td>
                </tr>
            </tbody>
        </table>
        <hr>
        <h2 class="mt-4">Partidos del Árbitro</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>DURACIÓN</th>
                    <th>TIPO</th>
                    <th>JORNADA</th>
                    <th>FECHA</th>
                    <th>RESULTADO</th>
                </tr>
            </thead>
            <tbody>
                @forelse($partidos as $partido)
                <tr>
                    <td>{{ $partido->id_Partido }}</td>
                    <td>{{ $partido->duracion }}</td>
                    <td>{{ $partido->tipo }}</td>
                    <td>{{ $partido->jornada }}</td>
                    <td>{{ $partido->fecha }}</td>
                    <td>{{ $partido->resultado }}</td>
                </tr>
                @empty
                <tr>
                    <td colspan="6">No se encontraron partidos para este árbitro.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script></body>
</html>
