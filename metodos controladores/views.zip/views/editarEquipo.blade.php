<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Equipo</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"></head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">MiAplicación</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarArbitros') }}">Arbitros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarJugadores') }}">Jugadores</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarCompeticiones') }}">Competiciones</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarEquipos') }}">Equipos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarJugadores') }}">Partidos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarEstadios') }}">Estadios</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Editar Equipo</h2>
        <form action="{{ route('actualizarEquipo', $equipo->id) }}" method="POST">
            @method('PUT')
            @csrf
            <fieldset>
                <legend>Edición de Equipo</legend>
                <div class="mb-3">
                    <label for="id" class="form-label">ID:</label>
                    <input type="number" class="form-control" id="id" name="id" value="{{ $equipo->id }}" readonly>
                </div>
                <div class="mb-3">
                    <label for="nombre_Equipo" class="form-label">Nombre:</label>
                    <input type="text" class="form-control" id="nombre_Equipo" name="nombre_Equipo" value="{{ $equipo->nombre_Equipo }}">
                    @error('nombre_Equipo')
                    <div class="text-danger">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="pais_Equipo" class="form-label">País:</label>
                    <input type="text" class="form-control" id="pais_Equipo" name="pais_Equipo" value="{{ $equipo->pais_Equipo }}">
                    @error('pais_Equipo')
                    <div class="text-danger">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="ciudad_Equipo" class="form-label">Ciudad:</label>
                    <input type="text" class="form-control" id="ciudad_Equipo" name="ciudad_Equipo" value="{{ $equipo->ciudad_Equipo }}">
                    @error('ciudad_Equipo')
                    <div class="text-danger">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="numero_plantilla" class="form-label">Número Plantilla:</label>
                    <input type="number" class="form-control" id="numero_plantilla" name="numero_plantilla" value="{{ $equipo->numero_plantilla }}">
                    @error('numero_plantilla')
                    <div class="text-danger">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="abreviacion" class="form-label">Abreviación:</label>
                    <input type="text" class="form-control" id="abreviacion" name="abreviacion" value="{{ $equipo->abreviacion }}">
                    @error('abreviacion')
                    <div class="text-danger">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="competicion_id" class="form-label">ID Competición:</label>
                    <input type="number" class="form-control" id="competicion_id" name="competicion_id" value="{{ $equipo->competicion_id }}">
                    @error('competicion_id')
                    <div class="text-danger">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="estadio_id" class="form-label">ID Estadio:</label>
                    <input type="number" class="form-control" id="estadio_id" name="estadio_id" value="{{ $equipo->estadio_id }}">
                    @error('estadio_id')
                    <div class="text-danger">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <div class="d-grid">
                    <input type="submit" class="btn btn-primary" name="Modificar" value="Modificar Equipo">
                </div>
            </fieldset>
        </form>
        @if (session('mensaje'))
        <div class="alert alert-warning mt-3">
            {{ session('mensaje') }}
        </div>
        @endif
        <a href="{{ route('mostrarEquipos') }}" class="btn btn-secondary mt-3">Volver</a>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script></body>
</html>
