<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Árbitro</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"></head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">MiAplicación</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarArbitros') }}">Arbitros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarJugadores') }}">Jugadores</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarCompeticiones') }}">Competiciones</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarEquipos') }}">Equipos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarJugadores') }}">Partidos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('mostrarEstadios') }}">Estadios</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Main Content -->
    <div class="container mt-5">
        <h2>Editar Árbitro</h2>
        <form action="{{ route('actualizarArbitro', $arbitro->id) }}" method="POST">
            @method('PUT')
            @csrf
            <fieldset class="border p-4">
                <legend class="w-auto">Edición de Árbitro</legend>
                <div class="mb-3">
                    <label for="id" class="form-label">ID:</label>
                    <input type="number" class="form-control" id="id" name="id" value="{{ $arbitro->id }}" readonly>
                </div>
                <div class="mb-3">
                    <label for="nombre_Arbitro" class="form-label">Nombre:</label>
                    <input type="text" class="form-control" id="nombre_Arbitro" name="nombre_Arbitro" value="{{ $arbitro->nombre_Arbitro }}">
                    @error('nombre_Arbitro')
                    <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="apellidos_Arbitro" class="form-label">Apellidos:</label>
                    <input type="text" class="form-control" id="apellidos_Arbitro" name="apellidos_Arbitro" value="{{ $arbitro->apellidos_Arbitro }}">
                    @error('apellidos_Arbitro')
                    <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="nacionalidad" class="form-label">Nacionalidad:</label>
                    <input type="text" class="form-control" id="nacionalidad" name="nacionalidad" value="{{ $arbitro->nacionalidad }}">
                    @error('nacionalidad')
                    <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="asignacion" class="form-label">Asignación:</label>
                    <input type="text" class="form-control" id="asignacion" name="asignacion" value="{{ $arbitro->asignacion }}">
                    @error('asignacion')
                    <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
                <button type="submit" class="btn btn-primary" name="Modificar">Modificar Árbitro</button>
            </fieldset>
        </form>
        @if (session('mensaje'))
        <div class="alert alert-warning mt-3">{{ session('mensaje') }}</div>
        @endif
        <a href="{{ route('mostrarArbitros') }}" class="btn btn-secondary mt-3">Volver</a>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script></body>
</html>
