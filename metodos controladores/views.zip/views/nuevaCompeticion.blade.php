<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alta Nueva Competición</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"></head>
<body>
   <!-- Navbar -->
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">MiAplicación</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarArbitros') }}">Arbitros</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarJugadores') }}">Jugadores</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarCompeticiones') }}">Competiciones</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarEquipos') }}">Equipos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarJugadores') }}">Partidos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('mostrarEstadios') }}">Estadios</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="#">Contacto</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <h2>Alta Nueva Competición</h2>
        <form action="{{ route('crearCompeticion') }}" method="POST">
            @csrf
            <fieldset class="border p-4">
                <legend class="w-auto">Nueva Competición</legend>
                <div class="mb-3">
                    <label for="nombre_Competicion" class="form-label">Nombre competición:</label>
                    <input type="text" class="form-control" id="nombre_Competicion" name="nombre_Competicion">
                    @error('nombre_Competicion')
                    <div style='color:red;'>{{ $message }}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="numero_Jornadas" class="form-label">Jornadas:</label>
                    <input type="text" class="form-control" id="numero_Jornadas" name="numero_Jornadas">
                    @error('numero_Jornadas')
                    <div style='color:red;'>{{ $message }}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="numero_Equipos" class="form-label">Número equipos:</label>
                    <input type="text" class="form-control" id="numero_Equipos" name="numero_Equipos">
                    @error('numero_Equipos')
                    <div style='color:red;'>{{ $message }}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="pais_Competicion" class="form-label">País:</label>
                    <input type="text" class="form-control" id="pais_Competicion" name="pais_Competicion">
                    @error('pais_Competicion')
                    <div style='color:red;'>{{ $message }}</div>
                    @enderror
                </div>
                <button type="submit" class="btn btn-primary" name="Insertar">Crear competición</button>
            </fieldset>
        </form>
        @if (session('mensaje'))
        <div class="alert alert-warning mt-3">{{ session('mensaje') }}</div>
        @endif
        <a href="{{ route('mostrarCompeticiones') }}" class="btn btn-secondary mt-3">Volver</a>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script></body>
</html>
